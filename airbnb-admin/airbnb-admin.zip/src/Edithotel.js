import React ,{useState,useEffect} from 'react';

import {AiFillPhone,AiFillCreditCard} from "react-icons/ai"
import {BsFillPersonFill} from "react-icons/bs"
import {MdEmail,MdEdit} from "react-icons/md"
import axios from "axios"
import {FaHotel} from "react-icons/fa"
import {MdLocationOn} from "react-icons/md"
import { useStateValue } from './StateProvider';
import "./AdminRegister.css"
import { useHistory } from 'react-router-dom';


function Edithotel() {
  
  var history = useHistory();
    const [hotel_details,setHotelDetails] = useState([]);
    var fetchUrl = "http://localhost:8000/hotel/details";
  
   
    
  
     useEffect(()=>{
          
          async function fetchData(){
              var request = await axios.get(fetchUrl);
    
       
             console.log(request.data)
              setHotelDetails(request.data)
  
          
        }
          fetchData();
        },[fetchUrl]);   

    var [edit_email,setEditEmail]=useState(hotel_details.hotel_email);
    var [edit_name,setEditName]=useState(hotel_details.hotel_name);
    
    var [edit_addr,setEditAddr]=useState(hotel_details.hotel_addr);
    var [edit_phone,setEditPhone]=useState(hotel_details.hotel_phone);
          

    console.log(hotel_details)
 
  

    var editUrl = `http://localhost:8000/edithotel`

     async function edit(){
        // setDisable(!disable);
        var request = await axios.put(editUrl,{
        
            "hotelname":edit_name,
            "hotelemail":edit_email,
            "phone":edit_phone,
           "addr":edit_addr,
      

          
        });

        history.push("/hotel_details")
       
       
    }
    return (

    
        
        <div  className="container">
              
       
             {
               hotel_details.map((item)=>(
           <form method="post" action="" enctype="multipart/form-data">
                    <h2 style={{textAlign:"center",fontSize:"16px",borderBottom:"2px sollid lightgrey",marginBottom:"10px"}}>Edit Hotel</h2>
                 
                 <label className="label" style={{paddingLeft:"0px"}}><FaHotel /> HotelName</label>
                 <input type="text" className="p_input" placeholder={item.hotel_name} onChange={(e)=>{setEditName(e.target.value)}}/>
             
             <label className="label" style={{paddingLeft:"0px"}}> Number</label>
                 <input type="number" className="p_input" placeholder={item.hotel_phone} onChange={(e)=>{setEditPhone(e.target.value)}}/>
                 <label className="label" style={{paddingLeft:"0px"}}> EmailID</label>
               <input type="text" className="p_input" placeholder={item.hotel_email} onChange={(e)=>{setEditEmail(e.target.value)}} />
                 <label className="label" style={{paddingLeft:"0px"}}> Address</label>
                 <input type="text" className="p_input" placeholder={item.hotel_addr} onChange={(e)=>{setEditAddr(e.target.value)}} />
  
     
         <button className="button" onClick={edit}> <MdEdit />Save</button>
        </form>
               ))
             }
      
           
        </div>
    )
}

export default Edithotel